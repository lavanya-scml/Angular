import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ProfilesComponent } from './components/profiles/profiles.component';
import { ProfileItemComponent } from './components/profile-item/profile-item.component';

const routes: Routes = [
  {
    path: '',
    component: ProfilesComponent,
  },

  {
    path: 'profile-item',
    component: ProfileItemComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ProfilesRoutingModule {}
