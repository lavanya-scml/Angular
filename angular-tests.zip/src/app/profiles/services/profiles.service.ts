import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class ProfilesService {
  constructor(private http: HttpClient) {}

  showProfile(): Observable<any> {
    return this.http.get('/api/profile');
  }

  loadProfiles(): Observable<any> {
    return this.http.get('/api/profile');
  }
}
