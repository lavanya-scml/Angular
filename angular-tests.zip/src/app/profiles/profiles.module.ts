import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ProfilesRoutingModule } from './profiles-routing.module';
import { ProfilesComponent } from './components/profiles/profiles.component';
import { ProfileItemComponent } from './components/profile-item/profile-item.component';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { httpInterceptorProviders } from '../core/interceptors';
import { ProfilesService } from './services/profiles.service';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [ProfilesComponent, ProfileItemComponent],
  imports: [CommonModule, FormsModule, HttpClientModule, ProfilesRoutingModule],
  providers: [httpInterceptorProviders, ProfilesService],
})
export class ProfilesModule {}
