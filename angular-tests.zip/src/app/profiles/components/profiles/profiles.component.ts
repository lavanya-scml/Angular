import { Component, OnInit } from '@angular/core';
import { Profile } from '../../models/profiles';
import { ProfilesService } from '../../services/profiles.service';

@Component({
  selector: 'app-profiles',
  templateUrl: './profiles.component.html',
  styleUrls: ['./profiles.component.css'],
})
export class ProfilesComponent implements OnInit {
  profile: Profile = new Profile();
  profiles: Profile[];

  constructor(private profileService: ProfilesService) {}

  showProfiles() {
    this.profileService.loadProfiles().subscribe((res) => {
      console.log(res);
      this.profiles = res;
    });
  }

  ngOnInit(): void {
    this.showProfiles();
  }
}
