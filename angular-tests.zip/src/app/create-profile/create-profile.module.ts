import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CreateProfileRoutingModule } from './create-profile-routing.module';
import { CreateProfileComponent } from './components/create-profile/create-profile.component';
import { httpInterceptorProviders } from '../core/interceptors';
import { FormsModule } from '@angular/forms';
import { CreateProfileService } from './services/create-profile.service';
import { HttpClientModule } from '@angular/common/http';

@NgModule({
  declarations: [CreateProfileComponent],
  imports: [
    CommonModule,
    HttpClientModule,
    FormsModule,
    CreateProfileRoutingModule,
  ],
  providers: [httpInterceptorProviders, CreateProfileService],
})
export class CreateProfileModule {}
