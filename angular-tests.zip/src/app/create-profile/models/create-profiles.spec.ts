import { CreateProfiles } from './create-profiles';

describe('CreateProfiles', () => {
  it('should create an instance', () => {
    expect(new CreateProfiles()).toBeTruthy();
  });
});
