import { Component, OnInit } from '@angular/core';
import { CreateProfiles } from '../../models/create-profiles';
import { CreateProfileService } from '../../services/create-profile.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-create-profile',
  templateUrl: './create-profile.component.html',
  styleUrls: ['./create-profile.component.css'],
})
export class CreateProfileComponent implements OnInit {
  createProfile: CreateProfiles = new CreateProfiles();
  constructor(
    private createProfileService: CreateProfileService,
    private router: Router
  ) {}
  createProfileSubmit() {
    this.createProfileService.createProfile(this.createProfile).subscribe(
      (res) => {
        console.log('succeess');
        this.router.navigate(['/dashboard']);
      },
      (err) => {
        console.log(JSON.stringify(err));
      }
    );
  }
  ngOnInit(): void {}
}
